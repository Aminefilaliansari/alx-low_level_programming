C - Function pointers
TASKS
