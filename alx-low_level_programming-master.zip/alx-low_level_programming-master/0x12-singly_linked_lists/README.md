TASKS
0x12. C - Singly linked lists
