C - Variadic functions 📁
TASKS 📃

